# CoreS3 SD Card Payload

Copy the contents of this folder to the SD card root.

Expected SD layout:

```text
/audio/ui/idle.raw
/audio/ui/photo.raw
/audio/ui/wild.raw
/audio/ui/bag.raw
/audio/ui/capture.raw
/audio/ui/release.raw
/audio/ui/select.raw
/audio/ui/warning.raw
/audio/ui/level_up.raw
/audio/ui/cancel.raw
/audio/battle/match.raw
/audio/battle/clash.raw
/audio/battle/friend.raw
/audio/battle/win.raw
/audio/battle/draw.raw
/audio/battle/lose.raw
/audio/battle/exit.raw
/audio/music/intro.raw
```

Format:

- unsigned 8-bit mono PCM
- 22050 Hz
- `.raw` payload only, no WAV/MP3 header
- each file is below the firmware limit of 32768 bytes

Current firmware reads these files as optional external sound assets. If a file
is missing or too large, the firmware falls back to built-in sound effects.
